#include "Sensor.h"
#include <iostream>
#include <fstream>
#include <algorithm>
#include <utility>

Sensor::~Sensor() {
    delete[] samples;
}

bool Sensor::isValid(double value) const {
    return (value >= minValue && value <= maxValue);
}

void Sensor::pushMeasurement(double val) {
    if (isValid(val)) {
        measurements.push_back(val);
    }
    else {
        log.warn(getName() + ": Pominieto wartosc poza zakresem (" + std::to_string(val) + ")");
    }
}

Sensor::Sensor(double minV, double maxV, LogLevel level)
    : samples(nullptr), sampleCount(0), log(std::cout, level), minValue(minV), maxValue(maxV) {
}

Sensor::Sensor(const Sensor& other)
    : measurements(other.measurements), sampleCount(other.sampleCount), log(other.log), minValue(other.minValue), maxValue(other.maxValue) {
    if (sampleCount > 0 && other.samples != nullptr) {
        samples = new double[sampleCount];
        std::copy(other.samples, other.samples + sampleCount, samples);
    }
    else {
        samples = nullptr;
    }
}

Sensor::Sensor(Sensor&& other) noexcept
    : measurements(std::move(other.measurements)),
    samples(other.samples),
    sampleCount(other.sampleCount),
    log(std::move(other.log)),
    minValue(other.minValue),
    maxValue(other.maxValue) {
    other.samples = nullptr;
    other.sampleCount = 0;
}

Sensor& Sensor::operator=(const Sensor& other) {
    if (this != &other) {
        delete[] samples;
        measurements = other.measurements;
        sampleCount = other.sampleCount;
        log = other.log;
        minValue = other.minValue;
        maxValue = other.maxValue;
        if (sampleCount > 0 && other.samples != nullptr) {
            samples = new double[sampleCount];
            std::copy(other.samples, other.samples + sampleCount, samples);
        }
        else {
            samples = nullptr;
        }
    }
    return *this;
}

Sensor& Sensor::operator=(Sensor&& other) noexcept {
    if (this != &other) {
        delete[] samples;
        measurements = std::move(other.measurements);
        samples = other.samples;
        sampleCount = other.sampleCount;
        log = std::move(other.log);
        minValue = other.minValue;
        maxValue = other.maxValue;

        other.samples = nullptr;
        other.sampleCount = 0;
    }
    return *this;
}

void Sensor::read_data(const std::string& meas_file, const std::string& samp_file) {
    std::ifstream f_meas(meas_file);
    if (f_meas.is_open()) {
        double val;
        while (f_meas >> val) {
            if (isValid(val)) {
                measurements.push_back(val);
            }
            else {
                log.warn(getName() + ": Pominieto wartosc poza zakresem (" + std::to_string(val) + ")");
            }
        }
        log.info(getName() + ": Poprawnie wczytano pomiary z " + meas_file);
    }
    else {
        log.error(getName() + ": Nie udalo sie otworzyc pliku " + meas_file);
    }

    if (!samp_file.empty()) {
        std::ifstream f_samp(samp_file);
        std::vector<double> tempSamples;
        if (f_samp.is_open()) {
            double val;
            while (f_samp >> val) tempSamples.push_back(val);
            log.info(getName() + ": Poprawnie wczytano probki kalibracyjne.");

            delete[] samples;
            sampleCount = tempSamples.size();
            if (sampleCount > 0) {
                samples = new double[sampleCount];
                std::copy(tempSamples.begin(), tempSamples.end(), samples);
            }
        }
        else {
            log.error(getName() + ": Nie udalo sie otworzyc pliku " + samp_file);
        }
    }
}

void Sensor::displayLast() const {
    if (!measurements.empty()) {
        std::cout << "Ostatni pomiar " << getName() << ": " << measurements.back() << "\n";
    }
    else {
        std::cout << "Brak pomiarow " << getName() << ".\n";
    }
}