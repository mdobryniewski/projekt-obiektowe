#pragma once
#include "Sensor.h"

class PHSensor : public Sensor {
public:
    PHSensor(double minV = 4.0, double maxV = 9.0, LogLevel lvl = LogLevel::INFO)
        : Sensor(minV, maxV, lvl) {
    }

    std::string getName() const override { return "PHSensor"; }
};
