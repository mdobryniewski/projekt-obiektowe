#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <iomanip>

#include "Logger.h"
#include "Properties.h"
#include "PHSensor.h"
#include "NO3Sensor.h"
#include "TempSensor.h"
#include "Meter.h"

#ifdef _WIN32
#include "getopt.h" 
#else
#include <unistd.h>
#include <getopt.h> 
#endif

using namespace std;

void printHelp() {
    std::cout << "Sensors v0.1 by Pawel Prokop\n";
    std::cout << "Usage: ./sensor OPTS\n";
    std::cout << "Options:\n";
    std::cout << "  -c FILE                     Configuration file\n";
    std::cout << "  -h                          This help message\n";
    std::cout << "  -l --log-level LOG_LEVEL    Logging level\n";
}

LogLevel parseLogLevel(const std::string& levelStr) {
    if (levelStr == "TRACE") return LogLevel::TRACE;
    if (levelStr == "DEBUG") return LogLevel::DEBUG;
    if (levelStr == "INFO") return LogLevel::INFO;
    if (levelStr == "WARN") return LogLevel::WARN;
    if (levelStr == "ERROR") return LogLevel::ERROR;
    return LogLevel::INFO;
}

int main(int argc, char* argv[]) {
    std::string configFile = "sensor.conf";
    bool logOverride = false;
    LogLevel cmdLogLevel = LogLevel::INFO;

    struct option long_options[] = {
        {"help", no_argument, 0, 'h'},
        {"loglevel", required_argument, 0, 'l'},
        {"log-level", required_argument, 0, 'l'},
        {0, 0, 0, 0}
    };

    int opt;
    int option_index = 0;
    while ((opt = getopt_long(argc, argv, "c:hl:", long_options, &option_index)) != -1) {
        switch (opt) {
        case 'c': configFile = optarg; break;
        case 'h': printHelp(); return 0;
        case 'l':
            cmdLogLevel = parseLogLevel(optarg);
            logOverride = true;
            break;
        default: printHelp(); return 1;
        }
    }

    Properties props;
    props.load(configFile);

    LogLevel finalLogLevel = logOverride ? cmdLogLevel : parseLogLevel(props.get("min_log_level", "INFO"));

    double phMin = std::stod(props.get("ph_min", "4.0"));
    double phMax = std::stod(props.get("ph_max", "9.0"));
    double no3Min = std::stod(props.get("no3_min", "0.0"));
    double no3Max = std::stod(props.get("no3_max", "300.0"));
    double tempMin = std::stod(props.get("temp_min", "0.0"));
    double tempMax = std::stod(props.get("temp_max", "40.0"));
    std::string logFileName = props.get("log_file", "");

    Logger mainLogger(std::cout, finalLogLevel);

    if (!logFileName.empty()) {
        mainLogger.setLogFile(logFileName);
    }

    mainLogger.info("Sensors start");

    std::cout << "\n--- Odczyt danych PHSensor ---\n";
    PHSensor ph(phMin, phMax, finalLogLevel);
    ph.read_data("ph_data.txt");
    ph.displayLast();

    std::cout << "\n--- Odczyt danych NO3Sensor ---\n";
    NO3Sensor no3(no3Min, no3Max, finalLogLevel);
    no3.read_data("no3_data.txt");
    no3.displayLast();

    std::cout << "\n--- Odczyt danych TempSensor ---\n";
    ifstream plik("temp_data.txt");
    vector<TempSensor> sensory;

    if (!plik.is_open()) {
        mainLogger.error("Blad otwarcia pliku temp_data.txt!");
    }
    else {
        string nazwa, tempStr;
        while (getline(plik, nazwa, ',')) {
            getline(plik, tempStr);

            if (tempStr.empty()) continue;

            try {
                TempSensor temp(nazwa, tempMin, tempMax, finalLogLevel);
                temp.setTemperatura(stod(tempStr));
                sensory.push_back(std::move(temp));
            }
            catch (...) {
            }
        }
        plik.close();

        cout << "Wczytano " << sensory.size() << " sensorow" << endl;
        cout << "Lp.   | Nazwa sensora             | Temperatura |" << endl;
        cout << "------+---------------------------+-------------+" << endl;
        for (size_t i = 0; i < sensory.size(); i++) {
            cout << left << setw(5) << (i + 1) << " | "
                << setw(25) << sensory[i].nazwa << " | "
                << right << setw(11) << fixed << setprecision(1) << sensory[i].temperatura << " |" << endl;
        }
    }

    std::cout << "\n--- Inicjalizacja Meter ---\n";
    TempSensor sampleTemp = sensory.empty() ? TempSensor("Brak", tempMin, tempMax) : sensory[0];

    Meter mainMeter(std::move(ph), sampleTemp, std::move(no3));
    mainLogger.info("Miernik zlozony (Kompozycja zakonczona sukcesem).");

    return 0;
}