#pragma once
#include "Sensor.h"

class NO3Sensor : public Sensor {
public:
    NO3Sensor(double minV = 0.0, double maxV = 300.0, LogLevel lvl = LogLevel::INFO)
        : Sensor(minV, maxV, lvl) {
    }

    std::string getName() const override { return "NO3Sensor"; }
};